;
(function() {
	angular.bootstrap(document.body, ["newsApp"])
})();