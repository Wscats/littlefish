;
(function() {
	var app = angular.module("newsApp", ["ui.router", "routes", "filters", "services", "controllers", "directives"]);
})();