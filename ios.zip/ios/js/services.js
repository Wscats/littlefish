;
(function() {
	var services = angular.module("services", []);
	services.service("tool", [function() {
		return {

		}
	}])
})();